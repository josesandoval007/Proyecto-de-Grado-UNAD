import cv2
import time
import os

# Carpeta para guardar videos
OUTPUT_DIR = "./static/videos"
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

def detect_motion():
    # Archivo de video en lugar de la cámara
    video_file = "prueba.mp4"  # Nombre del archivo de video
    camera = cv2.VideoCapture(video_file)  # Abre el archivo de video
    _, frame1 = camera.read()
    _, frame2 = camera.read()

    # Dimensiones del video de entrada
    frame_width = int(camera.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(camera.get(cv2.CAP_PROP_FRAME_HEIGHT))

    video_writer = None
    is_recording = False
    start_time = None

    while camera.isOpened():
        diff = cv2.absdiff(frame1, frame2)
        gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        _, thresh = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)
        dilated = cv2.dilate(thresh, None, iterations=3)
        contours, _ = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        # Detectar movimiento
        for contour in contours:
            if cv2.contourArea(contour) < 1000:
                continue

            if not is_recording:
                is_recording = True
                start_time = time.time()
                filename = os.path.join(OUTPUT_DIR, f"video_{int(start_time)}.avi")
                
                # Cambiar codec a DIVX y ajustar la resolución del video
                fourcc = cv2.VideoWriter_fourcc(*'DIVX')  # Cambié MJPG por DIVX
                video_writer = cv2.VideoWriter(filename, fourcc, 20.0, (frame_width, frame_height))
                print(f"Grabando: {filename}")

            break

        # Almacenar cuadro si está grabando
        if is_recording and video_writer:
            video_writer.write(frame1)
            print(f"Grabando video a: {filename}")  # Verifica si el archivo se está creando

            # Detener grabación después de 30 segundos sin movimiento
            if time.time() - start_time > 30:
                is_recording = False
                video_writer.release()
                print(f"Grabación finalizada: {filename}")

        # Mostrar video en tiempo real
        cv2.imshow("Video en tiempo real", frame1)
        frame1 = frame2
        ret, frame2 = camera.read()

        if not ret:  # Salir si el video ha terminado
            break

        if cv2.waitKey(10) == 27:  # Presiona 'Esc' para salir
            break

    camera.release()
    if video_writer:
        video_writer.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    detect_motion()
